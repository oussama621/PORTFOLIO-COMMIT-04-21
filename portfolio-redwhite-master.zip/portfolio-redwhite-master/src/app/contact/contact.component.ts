import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})

export class ContactComponent implements OnInit {
  name = 'Dynamic Form Action Demo';
  url ="https://getform.io/f/62f8089a-7af0-46a0-9d03-e9dede034f2a";

  constructor() { }

  ngOnInit(): void {
  }

}
